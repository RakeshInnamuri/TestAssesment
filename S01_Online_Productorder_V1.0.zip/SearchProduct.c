SearchProduct()
{
	
	///////////////////////////////////
	// Action: Search product in application
	// Pre-requisite: NA
	// Limitation: NA
	
web_reg_find("Text=Searchresults",  "SaveCount=pageCount1",LAST);


	// Transaction - Search for a product
	lr_start_transaction("001_Online_003_Search_CORE");
	
	web_submit_data("Search", 
		"Action=https://{P_HostURL}/search", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=Productid", "Value=1234", ENDITEM, 
		"Name=sessionid", "Value={C_Sessionid}", ENDITEM, 
		"Name=Search", "ValueMug", ENDITEM, 
		"Name=Languages", "Value=", ENDITEM, 
		LAST);
	
if(atoi(lr_eval_string("{pageCount1}")) !=0  && atoi(lr_eval_string("{pageCount2}")) !=0 )
		{
	        
	lr_end_transaction("001_Online_003_Search_CORE",LR_PASS);
				}
	else
		{
		    lr_save_datetime("%c", DATE_NOW, "p_errorTime");
		    lr_fail_trans_with_error("Unable to find product at  %s" ,lr_eval_string("{p_errorTime}"));
			lr_end_transaction("001_Online_003_Search_CORE",LR_FAIL);	
	}  
	
	lr_think_time(5);
	
	

	
	return 0;
}
