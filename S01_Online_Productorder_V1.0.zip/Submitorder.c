Submitorder()
	
{
		///////////////////////////////////
	// Action: Submit order for a product
	// Pre-requisite: Card details should be valid
	// Limitation: NA
	
 web_reg_save_param("Orderid",
					   "LB=orderid",
					   "RB=;",
					   "Search=ALL",
					   LAST);
/* Order ID is captured through C_Orderid */

web_reg_find("Text=confirmed",  "SaveCount=pageCount1",LAST);
web_reg_find("Text=orderid", "SaveCount=pageCount2",LAST);
	
	lr_rendezvous("placeorder");  // Using rendzvous to simulate a scenario of placing 10,000 order at the same time
	
	// Transaction - Place order for a product

	lr_start_transaction("001_Online_004_submitProductorder_CORE");
	
	web_submit_data("Order", 
		"Action=https://{P_HostURL}/Placeoder", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=Productid", "Value=1234", ENDITEM, 
		"Name=sessionid", "Value={C_Sessionid}", ENDITEM, 
		"Name=Carddetails", "Value=XXXXXXXXXXXXXXXXXX", ENDITEM, 
		"Name=Expiry", "Value=04/2020", ENDITEM,
        "Name=CVV", "Value=123", ENDITEM,		
		"Name=Price", "Value=119.0", ENDITEM, 
		"Name=Languages", "Value=", ENDITEM, 
		LAST);
	
if(atoi(lr_eval_string("{pageCount1}")) !=0  && atoi(lr_eval_string("{pageCount2}")) !=0 )
		{
	        
	lr_end_transaction("001_Online_004_submitProductorder_CORE",LR_PASS);
				}
	else
		{
		    lr_save_datetime("%c", DATE_NOW, "p_errorTime");
		    lr_fail_trans_with_error("Unable to submit order succesfully for user %s at  %s" ,lr_eval_string("{P_Username}"), lr_eval_string("{p_errorTime}"));
			lr_end_transaction("001_Online_004_submitProductorder_CORE",LR_FAIL);	
	}  
	
	lr_think_time(5);
	
	return 0;
}
