vuser_init()
{
	
/*Script Name: 001_Online_Productorder_V1.0	Author:  Rakesh Innamuri


Application: Online Retail	
Environment: NFT	
Release: XXXX
Date Created:  13/06/2019
Last Modified: 14/06/2019
Version: 1.0
Change History: 

Version 0.1 is created sample script for login,add product to cart and place order.
Version 0.2 : Included rendzvous point at Login and submit order transactions to simulate concurrency scenarios .
Version 1.0 : Included global verifictions 
				
 Test Cases: 
	
1. Welcome page.
2. Login
3. Search product
4. Place order.
5. Logout
 
 Estimated time for one iteration:  40 seconds.
 Rendezvous settings : 
 
 Login - Transaction # 2: 
 Release when 1000 Vusers arrive at the rendezvous select Timeout between Vusers: 160 seconds
 Place order Transaction #3 : 
 Release when 10000 Vusers arrive at the rendezvous select Timeout between Vusers: 1600 seconds

Rampup settings :

100 users every 10 seconds

*/
	
web_set_max_html_param_len("2048");
web_set_sockets_option("SSL_VERSION","TLS");


//Below are generic global validations errors expected during transaction failures.

web_global_verification("Text=An incorrect Username or Password was specified", "Fail=FOUND", "ID=Incorrect User Pass", LAST); 
web_global_verification("Text=The user account is locked or disabled", "Fail=FOUND", "ID=User Locked", LAST);

	return 0;
}
