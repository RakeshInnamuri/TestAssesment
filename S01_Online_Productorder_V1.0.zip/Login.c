Login()
{
	web_cache_cleanup();
	web_cleanup_cookies();
	web_cleanup_auto_headers();
	
	///////////////////////////////////
	// Action: Login into appliction
	// Pre-requisite:Login Credentials should be valid.
	// Limitation: N

	lr_start_transaction("001_Online_Product_order_Overall");

    web_reg_find("Text=Login - Oracle Access Management 11g", "SaveCount=pageCount1", LAST);
	
	// Transaction to  Launch application.	
	lr_start_transaction("001_Online_001_Welcome_CORE");

	
	web_url("Welcome.jspx", 
		"{P_HostURL}=https://{P_HostURL}/Welcome.jspx", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	
   if(atoi(lr_eval_string("{pageCount1}")) !=0)
		{
	        
	lr_end_transaction("001_Online_001_Welcome",LR_PASS);
				}
	else
		{
		    lr_save_datetime("%c", DATE_NOW, "p_errorTime");
		    lr_fail_trans_with_error("Unable to launch application and error encountered at %s" ,lr_eval_string("{p_errorTime}"));
       	lr_end_transaction("001_Online_001_Welcome_CORE",LR_FAIL);	
	}  
	
lr_think_time(5);

	/// Transaction: Login to Application

	// Correlations
	web_reg_save_param("C_Sessionid",
					   "LB=JSESSIONID=",
					   "RB=;",
					   "Search=ALL",
					   LAST);

	web_reg_save_param("c_afrLoop",
					   "LB=afrLoop\", \"",
					   "RB=\"",
					   LAST);
  
    web_reg_find("Text=login",  "SaveCount=pageCount1",LAST);
    web_reg_find("Text=Operations", "SaveCount=pageCount2",LAST);
	
	lr_rendezvous("login"); // Using rendzvous to simulate a scenario of 1000 user logging in at the same time

	lr_start_transaction("001_Online_002_Login_CORE");
	
	web_submit_data("auth_cred_submit", 
		"Action=https://{P_HostURL}/Login", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value={P_Username}", ENDITEM, 
		"Name=password", "Value={P_Password}", ENDITEM, 
		"Name=request_id", "Value=null", ENDITEM, 
		"Name=displayLangSelection", "Value=false", ENDITEM, 
		"Name=Languages", "Value=", ENDITEM, 
		LAST);
	
if(atoi(lr_eval_string("{pageCount1}")) !=0  && atoi(lr_eval_string("{pageCount2}")) !=0 )
		{
	        
	    lr_end_transaction("001_Online_002_Login_CORE",LR_PASS);
		
        }
	else
		{
		    lr_save_datetime("%c", DATE_NOW, "p_errorTime");
		    lr_fail_trans_with_error("Unable to login application and error encountered at %s for user %s" ,lr_eval_string("{p_errorTime}"),lr_eval_string("{P_Username}"));
			lr_end_transaction("001_Online_002_Login_CORE",LR_FAIL);	
	    }  
	
	lr_think_time(5);
	

	return 0;
}
