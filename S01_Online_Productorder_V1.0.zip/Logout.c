Logout()
{
	web_reg_find("Text=Loggedout",  "SaveCount=pageCount1",LAST);
   		
	lr_start_transaction("001_Online_005_Logout_CORE");
	// Transaction - Log out of application
	
	web_submit_data("Logout", 
		"Action=https://{P_HostURL}/Logout", 
		"Method=GET", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);
	
if(atoi(lr_eval_string("{pageCount1}")) !=0 )
		{
	        
	lr_end_transaction("001_Online_005_Logout_CORE",LR_PASS);
				}
	else
		{
		    lr_save_datetime("%c", DATE_NOW, "p_errorTime");
		    lr_fail_trans_with_error("Unable to loggedout of application,error encountered at %s" ,lr_eval_string("{p_errorTime}"));
			lr_end_transaction("001_Online_005_Logout_CORE",LR_FAIL);	
	}  
	
	lr_end_transaction("001_Online_Product_order_Overall",LR_AUTO);
	
	
	return 0;
}
